# livro_flask

Instalação do projeto nos capítulos 1 e 2 do livro.

Para saber mais conheça o livro. https://www.casadocodigo.com.br/products/livro-flask-a-z

from flask import Flask, render_template
from App.home import home

def create_app():
    app = Flask(__name__)

    app.register_blueprint(home)




    return app
